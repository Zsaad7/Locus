# Locus — démarrage

MVP React + Vite + Supabase. Objectif : tester le verrou d'accès à la station sur le terrain.

## 1. Créer le projet Supabase

1. Va sur [supabase.com](https://supabase.com) → **New project**.
2. Dans **SQL Editor** → **New query**, colle tout le contenu de `supabase-setup.sql` et clique **Run**. Ça crée les tables, les règles de sécurité (RLS), le trigger de création de profil, une station de test et quelques tâches.
3. **Important pour le MVP** : va dans **Authentication → Providers → Email** et **désactive "Confirm email"**. Sinon l'inscription ne connecte pas directement l'utilisateur (il faudrait valider un email), ce qui ralentit les tests.
4. Récupère tes clés dans **Project Settings → API** : l'`URL` du projet et la clé `anon public`.

## 2. Lancer l'application

```bash
cd locus
npm install
cp .env.example .env      # puis colle ton URL et ta clé anon dedans
npm run dev
```

Ouvre l'URL affichée (par défaut `http://localhost:5173`).

## 3. Tester le scénario complet

1. **Inscris un premier compte** — il est créé avec le rôle `salarie` par défaut.
2. Dans Supabase → **Table Editor → profiles**, passe ce compte en `role = responsable` (pour pouvoir tester la connexion libre + définir l'IP de la station). Assigne aussi un `shift` (`matin` / `apres_midi` / `nuit`) pour voir les tâches spécifiques.
3. **Connecte-toi comme responsable depuis la station**, va dans le bloc **Station** du tableau de bord et clique sur **« Définir l'IP actuelle comme IP de la station »**. L'IP publique de la station est enregistrée.
4. **Inscris un second compte** (reste en `salarie`) :
   - Sur le WiFi de la station → connexion **autorisée**.
   - En 4G / hors station → connexion **refusée** (« Connexion autorisée uniquement depuis la station »).
5. Reste connecté comme salarié puis coupe le WiFi de la station : dans les 30 secondes, la session se ferme automatiquement.

## 4. Ce qui est volontairement simple (à durcir plus tard)

- **La vérif d'IP est côté client** (le navigateur lit sa propre IP publique via ipify). Suffisant pour tester les réactions des employés, mais contournable. Le durcissement se fait avec une **Supabase Edge Function** qui lit l'IP réelle de la requête côté serveur, ou avec le backend NestJS.
- **IP dynamique** : si l'IP publique de la station change, le responsable reclique simplement sur le bouton pour la remettre à jour.
- **Attribution des points, avertissements, gestion des tâches par le responsable** : à ajouter (interface admin).

## Structure

```
locus/
├── supabase-setup.sql        # à exécuter dans Supabase
├── .env.example
├── index.html
├── package.json
├── vite.config.ts
└── src/
    ├── main.tsx
    ├── App.tsx               # navigation login / dashboard / tâches
    ├── index.css
    ├── lib/
    │   ├── supabase.ts       # client Supabase
    │   └── geofence.ts       # lecture IP publique + comparaison
    ├── context/
    │   └── AuthContext.tsx   # auth + application du géofencing
    └── pages/
        ├── Login.tsx
        ├── Dashboard.tsx     # infos, pointage, avertissements, points, IP station
        └── Tasks.tsx         # tâches communes + spécifiques au poste
```
