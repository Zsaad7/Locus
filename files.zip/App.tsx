import { useState } from 'react'
import { useAuth } from './context/AuthContext'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Tasks from './pages/Tasks'

export default function App() {
  const { session, loading, signOut } = useAuth()
  const [tab, setTab] = useState<'dashboard' | 'tasks'>('dashboard')

  if (loading) return <div className="center"><p>Chargement...</p></div>
  if (!session) return <Login />

  return (
    <div className="app">
      <header className="topbar">
        <strong>Locus</strong>
        <nav>
          <button className={tab === 'dashboard' ? 'active' : ''} onClick={() => setTab('dashboard')}>
            Tableau de bord
          </button>
          <button className={tab === 'tasks' ? 'active' : ''} onClick={() => setTab('tasks')}>
            Tâches
          </button>
        </nav>
        <button className="link" onClick={signOut}>Déconnexion</button>
      </header>
      <main>
        {tab === 'dashboard' ? <Dashboard /> : <Tasks />}
      </main>
    </div>
  )
}
