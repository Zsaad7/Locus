// Récupère l'IP publique du client via un service externe.
// Sur le WiFi de la station, tous les appareils partagent la même IP publique (NAT).
export async function getPublicIp(): Promise<string | null> {
  try {
    const res = await fetch('https://api.ipify.org?format=json')
    const data = await res.json()
    return data.ip ?? null
  } catch {
    return null
  }
}

// Le salarié est "à la station" si son IP publique == l'IP autorisée de la station.
export function isAtStation(clientIp: string | null, allowedIp: string | null): boolean {
  if (!allowedIp) return false // IP de la station pas encore définie
  return clientIp !== null && clientIp === allowedIp
}
