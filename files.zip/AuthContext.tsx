import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'
import { getPublicIp, isAtStation } from '../lib/geofence'

export type Profile = {
  id: string
  full_name: string
  role: 'responsable' | 'salarie'
  shift: 'matin' | 'apres_midi' | 'nuit' | null
  points: number
  station_id: string | null
}

export type Station = { id: string; name: string; allowed_ip: string | null }

type AuthState = {
  session: Session | null
  profile: Profile | null
  station: Station | null
  loading: boolean
  geofenceError: string | null
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, fullName: string) => Promise<void>
  signOut: () => Promise<void>
  refreshStationIp: () => Promise<void>
}

const Ctx = createContext<AuthState | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [station, setStation] = useState<Station | null>(null)
  const [loading, setLoading] = useState(true)
  const [geofenceError, setGeofenceError] = useState<string | null>(null)

  async function loadProfileAndStation(userId: string) {
    const { data: prof } = await supabase
      .from('profiles').select('*').eq('id', userId).single()

    let st: Station | null = null
    if (prof?.station_id) {
      const { data } = await supabase
        .from('stations').select('*').eq('id', prof.station_id).single()
      st = data as Station
    } else {
      // MVP mono-station : on prend la première station
      const { data } = await supabase
        .from('stations').select('*').limit(1).single()
      st = data as Station
    }

    setProfile(prof as Profile)
    setStation(st)
    return { prof: prof as Profile, st }
  }

  // Bloque le salarié hors station. Le responsable passe toujours.
  async function enforceGeofence(prof: Profile, st: Station | null): Promise<boolean> {
    if (prof.role === 'responsable') { setGeofenceError(null); return true }
    const ip = await getPublicIp()
    if (!isAtStation(ip, st?.allowed_ip ?? null)) {
      setGeofenceError('Connexion autorisée uniquement depuis la station.')
      await supabase.auth.signOut()
      return false
    }
    setGeofenceError(null)
    return true
  }

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session)
      if (data.session) await loadProfileAndStation(data.session.user.id)
      setLoading(false)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s)
      if (!s) { setProfile(null); setStation(null) }
    })
    return () => sub.subscription.unsubscribe()
  }, [])

  // Re-vérification périodique : verrouille la session à la station.
  // Dès que le salarié quitte le WiFi de la station, la session se ferme.
  useEffect(() => {
    if (!session || !profile || profile.role === 'responsable') return
    const interval = setInterval(async () => {
      const ip = await getPublicIp()
      if (!isAtStation(ip, station?.allowed_ip ?? null)) {
        setGeofenceError('Vous avez quitté la station. Session fermée.')
        await supabase.auth.signOut()
      }
    }, 30000)
    return () => clearInterval(interval)
  }, [session, profile, station])

  async function signIn(email: string, password: string) {
    setGeofenceError(null)
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw error
    const { prof, st } = await loadProfileAndStation(data.user.id)
    const ok = await enforceGeofence(prof, st)
    if (!ok) throw new Error('Connexion autorisée uniquement depuis la station.')
  }

  async function signUp(email: string, password: string, fullName: string) {
    const { error } = await supabase.auth.signUp({
      email, password,
      options: { data: { full_name: fullName } },
    })
    if (error) throw error
  }

  async function signOut() {
    await supabase.auth.signOut()
  }

  // Le responsable définit l'IP courante comme IP autorisée de la station.
  async function refreshStationIp() {
    if (!station || profile?.role !== 'responsable') return
    const ip = await getPublicIp()
    if (!ip) return
    await supabase.from('stations').update({ allowed_ip: ip }).eq('id', station.id)
    setStation({ ...station, allowed_ip: ip })
  }

  return (
    <Ctx.Provider value={{
      session, profile, station, loading, geofenceError,
      signIn, signUp, signOut, refreshStationIp,
    }}>
      {children}
    </Ctx.Provider>
  )
}

export function useAuth() {
  const c = useContext(Ctx)
  if (!c) throw new Error('useAuth doit être utilisé dans <AuthProvider>')
  return c
}
