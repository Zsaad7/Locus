import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

type Attendance = { id: string; clock_in: string; clock_out: string | null }
type Warning = { id: string; reason: string; severity: string; created_at: string }

export default function Dashboard() {
  const { profile, station, refreshStationIp } = useAuth()
  const [openAttendance, setOpenAttendance] = useState<Attendance | null>(null)
  const [warnings, setWarnings] = useState<Warning[]>([])
  const [busy, setBusy] = useState(false)

  async function loadData() {
    if (!profile) return
    const { data: att } = await supabase
      .from('attendance').select('*')
      .eq('user_id', profile.id).is('clock_out', null)
      .order('clock_in', { ascending: false }).limit(1)
    setOpenAttendance(att && att.length ? (att[0] as Attendance) : null)

    const { data: w } = await supabase
      .from('warnings').select('*')
      .eq('user_id', profile.id).order('created_at', { ascending: false })
    setWarnings((w ?? []) as Warning[])
  }

  useEffect(() => { loadData() }, [profile])

  async function clockIn() {
    if (!profile) return
    setBusy(true)
    await supabase.from('attendance').insert({ user_id: profile.id })
    await loadData(); setBusy(false)
  }

  async function clockOut() {
    if (!openAttendance) return
    setBusy(true)
    await supabase.from('attendance')
      .update({ clock_out: new Date().toISOString() })
      .eq('id', openAttendance.id)
    await loadData(); setBusy(false)
  }

  if (!profile) return null

  return (
    <div className="stack">
      <section className="card">
        <h2>{profile.full_name}</h2>
        <p className="muted">
          Rôle : {profile.role}{profile.shift ? ` · Poste : ${profile.shift}` : ''}
        </p>
        <p>Points : <strong>{profile.points}</strong></p>
      </section>

      <section className="card">
        <h3>Pointage</h3>
        {openAttendance ? (
          <>
            <p className="muted">
              Entré à {new Date(openAttendance.clock_in).toLocaleTimeString()}
            </p>
            <button disabled={busy} onClick={clockOut}>Pointer la sortie</button>
          </>
        ) : (
          <button disabled={busy} onClick={clockIn}>Pointer l'entrée</button>
        )}
      </section>

      <section className="card">
        <h3>Avertissements</h3>
        {warnings.length === 0 ? (
          <p className="muted">Aucun avertissement.</p>
        ) : (
          <ul>
            {warnings.map(w => (
              <li key={w.id}><strong>{w.severity}</strong> — {w.reason}</li>
            ))}
          </ul>
        )}
      </section>

      {profile.role === 'responsable' && (
        <section className="card">
          <h3>Station</h3>
          <p className="muted">IP autorisée : {station?.allowed_ip ?? 'non définie'}</p>
          <button onClick={refreshStationIp}>
            Définir l'IP actuelle comme IP de la station
          </button>
        </section>
      )}
    </div>
  )
}
