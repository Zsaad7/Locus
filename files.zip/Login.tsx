import { useState, FormEvent } from 'react'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { signIn, signUp, geofenceError } = useAuth()
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function submit(e: FormEvent) {
    e.preventDefault()
    setError(null); setLoading(true)
    try {
      if (mode === 'login') await signIn(email, password)
      else await signUp(email, password, fullName)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erreur')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="center">
      <form className="card" onSubmit={submit}>
        <h1>Locus</h1>
        <p className="muted">{mode === 'login' ? 'Connexion' : 'Créer un compte'}</p>

        {mode === 'signup' && (
          <input
            placeholder="Nom complet"
            value={fullName}
            onChange={e => setFullName(e.target.value)}
            required
          />
        )}
        <input
          type="email" placeholder="Email"
          value={email} onChange={e => setEmail(e.target.value)} required
        />
        <input
          type="password" placeholder="Mot de passe"
          value={password} onChange={e => setPassword(e.target.value)} required
        />

        <button disabled={loading}>
          {loading ? '...' : mode === 'login' ? 'Se connecter' : "S'inscrire"}
        </button>

        {(error || geofenceError) && <p className="error">{error || geofenceError}</p>}

        <button
          type="button" className="link"
          onClick={() => { setError(null); setMode(mode === 'login' ? 'signup' : 'login') }}
        >
          {mode === 'login' ? "Pas de compte ? S'inscrire" : 'Déjà un compte ? Se connecter'}
        </button>
      </form>
    </div>
  )
}
