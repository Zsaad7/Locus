-- =============================================================
-- Locus — setup Supabase
-- À coller dans : Supabase Dashboard > SQL Editor > New query > Run
-- =============================================================

-- Types
create type user_role as enum ('responsable', 'salarie');
create type work_shift as enum ('matin', 'apres_midi', 'nuit');

-- Stations
create table public.stations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  allowed_ip text,
  created_at timestamptz default now()
);

-- Profils (liés à auth.users)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role user_role not null default 'salarie',
  shift work_shift,
  points int not null default 0,
  station_id uuid references public.stations(id),
  created_at timestamptz default now()
);

-- Pointage
create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  clock_in timestamptz not null default now(),
  clock_out timestamptz
);

-- Avertissements
create table public.warnings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  reason text not null,
  severity text not null default 'info',
  created_at timestamptz default now()
);

-- Tâches
create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  scope text not null default 'common',   -- 'common' | 'specific'
  shift work_shift,                        -- null pour les tâches communes
  station_id uuid references public.stations(id),
  created_at timestamptz default now()
);

-- Complétions de tâches
create table public.task_completions (
  id uuid primary key default gen_random_uuid(),
  task_id uuid references public.tasks(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  completed_at timestamptz default now(),
  unique (task_id, user_id)
);

-- =============================================================
-- Création automatique du profil à l'inscription
-- =============================================================
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email), 'salarie');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- =============================================================
-- Row Level Security
-- =============================================================
alter table public.profiles enable row level security;
alter table public.stations enable row level security;
alter table public.attendance enable row level security;
alter table public.warnings enable row level security;
alter table public.tasks enable row level security;
alter table public.task_completions enable row level security;

-- Helper (security definer => évite la récursion RLS sur profiles)
create or replace function public.is_responsable()
returns boolean as $$
  select exists(
    select 1 from public.profiles
    where id = auth.uid() and role = 'responsable'
  );
$$ language sql security definer stable;

-- profiles : chacun voit/modifie son profil
create policy profiles_select_own on public.profiles for select using (auth.uid() = id);
create policy profiles_update_own on public.profiles for update using (auth.uid() = id);

-- stations : lecture par tout authentifié, mise à jour par le responsable
create policy stations_select on public.stations for select to authenticated using (true);
create policy stations_update on public.stations for update to authenticated using (public.is_responsable());

-- attendance : chacun gère son pointage
create policy attendance_select_own on public.attendance for select using (auth.uid() = user_id);
create policy attendance_insert_own on public.attendance for insert with check (auth.uid() = user_id);
create policy attendance_update_own on public.attendance for update using (auth.uid() = user_id);

-- warnings : lecture des siens ; création par le responsable
create policy warnings_select_own on public.warnings for select using (auth.uid() = user_id);
create policy warnings_insert_resp on public.warnings for insert with check (public.is_responsable());

-- tasks : lecture par tout authentifié ; gestion par le responsable
create policy tasks_select on public.tasks for select to authenticated using (true);
create policy tasks_manage_resp on public.tasks for all to authenticated
  using (public.is_responsable()) with check (public.is_responsable());

-- task_completions : chacun gère les siennes
create policy tc_select_own on public.task_completions for select using (auth.uid() = user_id);
create policy tc_insert_own on public.task_completions for insert with check (auth.uid() = user_id);
create policy tc_delete_own on public.task_completions for delete using (auth.uid() = user_id);

-- =============================================================
-- Données de départ (une station + quelques tâches)
-- =============================================================
do $$
declare sid uuid;
begin
  insert into public.stations (name, allowed_ip)
  values ('Station Test', null)
  returning id into sid;

  insert into public.tasks (title, scope, shift, station_id) values
    ('Vérifier la propreté de la piste', 'common', null, sid),
    ('Contrôler les niveaux de caisse',  'common', null, sid),
    ('Relever les index des pompes',      'specific', 'matin', sid),
    ('Réassort boutique',                 'specific', 'apres_midi', sid),
    ('Nettoyage complet de la station',   'specific', 'nuit', sid);
end $$;
