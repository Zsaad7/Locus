import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

type Task = { id: string; title: string; scope: 'common' | 'specific'; shift: string | null }

export default function Tasks() {
  const { profile } = useAuth()
  const [tasks, setTasks] = useState<Task[]>([])
  const [done, setDone] = useState<Set<string>>(new Set())

  async function load() {
    if (!profile) return

    let query = supabase.from('tasks').select('*')
    if (profile.shift) {
      // communes + spécifiques au poste du salarié
      query = query.or(`scope.eq.common,and(scope.eq.specific,shift.eq.${profile.shift})`)
    } else {
      query = query.eq('scope', 'common')
    }
    const { data } = await query
    setTasks((data ?? []) as Task[])

    const { data: comp } = await supabase
      .from('task_completions').select('task_id').eq('user_id', profile.id)
    setDone(new Set((comp ?? []).map((c: { task_id: string }) => c.task_id)))
  }

  useEffect(() => { load() }, [profile])

  async function toggle(taskId: string) {
    if (!profile) return
    if (done.has(taskId)) {
      await supabase.from('task_completions')
        .delete().eq('task_id', taskId).eq('user_id', profile.id)
    } else {
      await supabase.from('task_completions')
        .insert({ task_id: taskId, user_id: profile.id })
    }
    await load()
  }

  const common = tasks.filter(t => t.scope === 'common')
  const specific = tasks.filter(t => t.scope === 'specific')

  return (
    <div className="stack">
      <section className="card">
        <h3>Tâches communes</h3>
        <TaskList tasks={common} done={done} onToggle={toggle} />
      </section>

      <section className="card">
        <h3>Tâches du poste {profile?.shift ? `(${profile.shift})` : ''}</h3>
        {profile?.shift
          ? <TaskList tasks={specific} done={done} onToggle={toggle} />
          : <p className="muted">Aucun poste assigné.</p>}
      </section>
    </div>
  )
}

function TaskList({
  tasks, done, onToggle,
}: {
  tasks: Task[]
  done: Set<string>
  onToggle: (id: string) => void
}) {
  if (!tasks.length) return <p className="muted">Aucune tâche.</p>
  return (
    <ul className="tasks">
      {tasks.map(t => (
        <li key={t.id}>
          <label>
            <input
              type="checkbox"
              checked={done.has(t.id)}
              onChange={() => onToggle(t.id)}
            />
            <span className={done.has(t.id) ? 'strike' : ''}>{t.title}</span>
          </label>
        </li>
      ))}
    </ul>
  )
}
